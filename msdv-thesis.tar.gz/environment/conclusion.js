document.addEventListener('keydown', function (event) {
    if (event.code === 'ArrowLeft') {
        window.location.href = 'universes.html';
    }
});

document.addEventListener('keydown', function (event) {
    if (event.code === 'ArrowRight') {
        window.location.href = 'about.html';
    }
});